def main():
    phone = "6174951000"
    print(phone[6:10])


main()
