def main():
    phone = "6174951000"
    print(phone[:3])


main()
