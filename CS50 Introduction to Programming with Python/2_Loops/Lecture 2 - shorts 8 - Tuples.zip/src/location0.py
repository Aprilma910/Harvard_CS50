def main():
    coordinates = (42.376, -71.115)


main()
