def main():
    coordinates = (42.376, -71.115)
    print(f"Latitude: {coordinates[0]}")
    print(f"Longitude: {coordinates[1]}")


main()
