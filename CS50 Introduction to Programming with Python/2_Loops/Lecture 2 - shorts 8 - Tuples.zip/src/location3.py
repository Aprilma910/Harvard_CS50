def main():
    coordinates = (42.376, -71.115)
    coordinates[0] = -42.376


main()
