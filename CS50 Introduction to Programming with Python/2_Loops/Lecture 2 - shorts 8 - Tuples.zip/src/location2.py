def main():
    coordinates = (42.376, -71.115)
    lat, long = coordinates
    print(f"Latitude: {lat}")
    print(f"Longitude: {long}")


main()
