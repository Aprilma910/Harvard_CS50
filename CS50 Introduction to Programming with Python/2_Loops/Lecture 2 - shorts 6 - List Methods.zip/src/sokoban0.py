def main():
    history = []

    while True:
        action = input("Action: ")
        history.append(action)
        print(history)


main()
