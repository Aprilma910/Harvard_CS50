def main(): ...


def recommend(game):
    print("You might like", game)


main()
