# Uses cowsay module

import cowsay

cowsay.cow("This is CS50")
