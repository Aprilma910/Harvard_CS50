# Gets input

import cowsay

name = input("What's your name? ")
cowsay.cow(f"hello, {name}")
