# Doesn't handle exception

# Prompt user for an integer
n = int(input("Input: "))
print("Integer")
