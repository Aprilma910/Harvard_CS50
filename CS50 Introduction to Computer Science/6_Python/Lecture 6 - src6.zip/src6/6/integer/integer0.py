# Checks whether integer using conditional

# Prompt user for an integer
n = input("Input: ")
if n.isnumeric():
    print("Integer.")
else:
    print("Not integer.")
