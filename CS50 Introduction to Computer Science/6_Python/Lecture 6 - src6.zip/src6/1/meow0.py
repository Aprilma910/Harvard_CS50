# Opportunity for better design

print("meow")
print("meow")
print("meow")
