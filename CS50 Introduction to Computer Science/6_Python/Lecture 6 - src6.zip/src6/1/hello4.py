# Says hello without a newline

print("hello, world", end="")
