# Prints a 3-by-3 grid of bricks with loop and * operator

for i in range(3):
    print("#" * 3)
