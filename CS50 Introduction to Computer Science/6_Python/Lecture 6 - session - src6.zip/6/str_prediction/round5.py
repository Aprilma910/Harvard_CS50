phrase = "You're off to Great Places"

print("Round 5: ")
modified = phrase.split(" ")
for word in modified:
    print(word)
print("")
