phrase = "You're off to Great Places"

print("Round 2: ", end="")
for i in range(1, len(phrase) - 1):
    print(phrase[i], end="")
print("")
