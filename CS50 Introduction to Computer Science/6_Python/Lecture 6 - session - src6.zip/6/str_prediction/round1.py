phrase = "You're off to Great Places"

print("Round 1: ", end="")
for i in range(0, len(phrase), 2):
    print(phrase[i], end="")
print()
