phrase = "You're off to Great Places"

print("Round 4: ", end="")
for character in phrase[7:]:
    print(character, end=" ")
print("")
